import About from '../About';

export default function AboutExample() {
  return <About />;
}
