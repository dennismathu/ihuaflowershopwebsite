import CTABanner from '../CTABanner';

export default function CTABannerExample() {
  return <CTABanner />;
}
