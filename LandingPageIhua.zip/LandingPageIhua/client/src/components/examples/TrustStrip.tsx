import TrustStrip from '../TrustStrip';

export default function TrustStripExample() {
  return <TrustStrip />;
}
