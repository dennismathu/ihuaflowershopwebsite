import FeaturedBouquets from '../FeaturedBouquets';

export default function FeaturedBouquetsExample() {
  return <FeaturedBouquets />;
}
